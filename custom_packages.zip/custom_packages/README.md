sudo python setup.py sdist
tar -tvf dist/custom_packages-0.1.tar.gz 
sudo mv dist/custom_packages-0.1.tar.gz packages/
sudo pypi-server --port=8080 /var/www/html/PythonLibs/custom_packages/packages/

