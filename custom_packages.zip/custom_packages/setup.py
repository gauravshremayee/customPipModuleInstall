from setuptools import setup

setup(
    name='custom_packages',
    packages=['custom_packages'],
    description='Hello world  edition',
    version='0.1',
    url='http://github.com/gauravshremayee/PythonDayOne',
    author='witty',
    author_email='admin@wittymindstech.com',
    keywords=['pip','witty','example'],
    #package_dir={'':'/var/www/html/PythonLibs/custom_packages/packages'}
    )
